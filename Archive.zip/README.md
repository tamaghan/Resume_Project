# Resume_Project

Personal website to display continually updated information about my skills and experiences. The project was developed with the knowledge of CSS/HTML.
